
from django.contrib import admin
from django.urls import path, include
from .views import *
from rest_framework import routers

router = routers.DefaultRouter()

router.register('disponibilidad', DisponibilidadViewSet)
router.register('cita', CitaViewSet)



urlpatterns = [
    path('', include(router.urls)),
    path('get-schedule/', send_schedule, name='get-schedule'),
]
