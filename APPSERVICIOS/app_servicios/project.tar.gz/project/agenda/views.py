from rest_framework import  viewsets, status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from .models import *
from .serializers import *
import datetime
import time


# Create your views here.



@api_view(['POST'])
def send_schedule(request):

    try:
        init = datetime.datetime.strptime(request.data['init'], '%Y-%m-%d')
        finish = datetime.datetime.strptime(request.data['finish'], '%Y-%m-%d')
    except:
        init = None
        finish = None

    if init and finish:
        i = init
        count = 0

        response = []

        while i <= finish:

            disponibilidades = Disponibilidad.objects.filter(inicio__date=i.date(), cancel=False)
            disponibilidades_serializer = DisponibilidadSerializer(disponibilidades, many=True)

            add = {
                "day": {"day": count, "date": i.date()},
                "disponibilidades": disponibilidades_serializer.data
            }
            response.append(add)
            i = i + datetime.timedelta(days=1)
            count += 1

        
 

        return Response(response)





class DisponibilidadViewSet(viewsets.ModelViewSet):
    queryset = Disponibilidad.objects.all()
    serializer_class = DisponibilidadSerializer
    filter_backends = (DjangoFilterBackend,)
    filter_fields = ('cancel',)

    def get_queryset(self):
        time.sleep(3)
        return super().get_queryset()
    
   
    

class CitaViewSet(viewsets.ModelViewSet):
    queryset = Cita.objects.all()
    serializer_class = CitaSerializer
    filter_backends = (DjangoFilterBackend,)
    # permission_classes = (OnlyAdminPerPag,)
    filter_fields = ('demandante',)